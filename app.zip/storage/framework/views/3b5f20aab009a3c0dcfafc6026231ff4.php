
<?php $__env->startSection('title', 'Home Page'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-xxl">
    <div class="py-3 d-flex align-items-sm-center flex-sm-row flex-column">
        <div class="flex-grow-1">
            <h4 class="fs-18 fw-semibold m-0">Dashboard</h4>
        </div>
    </div>

    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="fa fa-check-circle me-2"></i> 
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h5 class="card-title">All Orders</h5>
        </div>
        <div class="card-body">
            <?php if($orders->isEmpty()): ?>
                <p>No orders found.</p> 
            <?php else: ?>
                <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?> 
                    </div>
                <?php endif; ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Username</th> 
                            <th>Pickup Location</th>
                            <th>Delivery Location</th>
                            <th>Size/Weight</th>
                            <th>Pickup Date</th>
                            <th>Delivery Date</th>
                            <th>Status</th>
                            <th>Order Date/Time</th>
                            <th>Actions</th> 
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <tr>
                                <td><?php echo e($order->id); ?></td>
                                <td><?php echo e($order->user->name ?? 'N/A'); ?></td> 
                                <td><?php echo e($order->pickup_location); ?></td>
                                <td><?php echo e($order->delivery_location); ?></td>
                                <td><?php echo e($order->size_weight); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($order->pickup_datetime)->translatedFormat('j F Y')); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($order->delivery_datetime)->translatedFormat('j F Y')); ?></td>
                                <td>
                            <?php if($order->status === 'Pending'): ?>
                                <span class="badge bg-warning text-dark">
                                    <i class="bi bi-clock-fill me-1"></i> 🕒 Pending
                                </span>
                            <?php elseif($order->status === 'In-Progress'): ?>
                                <span class="badge bg-info text-dark">
                                    <i class="bi bi-arrow-repeat me-1"></i> 🚧 In-Progress
                                </span>
                            <?php elseif($order->status === 'Delivered'): ?>
                                <span class="badge bg-success text-white">
                                    <i class="bi bi-check-circle-fill me-1"></i>✅ Delivered
                                </span>
                            <?php else: ?>
                                <span class="badge bg-secondary text-white">
                                    <i class="bi bi-question-circle-fill me-1"></i> Unknown
                                </span>
                            <?php endif; ?>
                        </td>

                                <td><?php echo e(\Carbon\Carbon::parse($order->created_at)->translatedFormat('j F Y H:i')); ?></td>
                                <td>
                                    <form action="<?php echo e(route('orders.updateStatus', $order->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <div class="input-group">
                                        <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                                            <option value="" disabled selected>Select Status</option>
                                            <option value="Pending" class="bg-warning text-dark">🕒 Pending</option>
                                            <option value="In-Progress" class="bg-primary text-white">🚧 In Progress</option>
                                            <option value="Delivered" class="bg-success text-white">✅ Delivered</option>
                                        </select>
                                    </div>
                                </form>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\TruckRequestOrdering\resources\views/dashboard.blade.php ENDPATH**/ ?>