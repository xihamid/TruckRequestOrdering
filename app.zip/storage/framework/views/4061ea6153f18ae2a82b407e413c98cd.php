<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>

    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>">

    <!-- App css -->
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="app-style" />

    <!-- Icons -->
    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="row vh-100">
    <div class="col-12">
        <div class="p-0">
            <div class="row d-flex align-items-center">
                <div class="col-md-6 col-xl-6 col-lg-6">
                    <div class="row">
                        <div class="col-md-6 mx-auto">
                            <div class="mb-0 border-0">
                                <div class="p-0">
                                    <div class="text-center">
                                        <div class="mb-4">
                                            <!-- <a href="<?php echo e(url('/')); ?>" class="auth-logo">
                                                <img src="<?php echo e(asset('assets/images/logo-dark.png')); ?>" alt="logo-dark" class="mx-auto" height="28" />
                                            </a> -->
                                        </div>

                                        <div class="auth-title-section mb-3"> 
                                            <h3 class="text-dark fs-20 fw-medium mb-2">Admin Login</h3>
                                            <p class="text-dark text-capitalize fs-14 mb-0">Please enter your details.</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="pt-0">
                                    <!-- Display error and success messages -->
                                    <?php if($errors->any() || session('message') || session('error')): ?>
                                        <div class="mb-4">
                                            <?php if($errors->any()): ?>
                                                <div class="alert alert-danger">
                                                    <ul class="mb-0">
                                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li><?php echo e($error); ?></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </div>
                                            <?php endif; ?>

                                            <?php if(session('message')): ?>
                                                <div class="alert alert-success">
                                                    <?php echo e(session('message')); ?>

                                                </div>
                                            <?php endif; ?>

                                            <?php if(session('error')): ?>
                                                <div class="alert alert-danger">
                                                    <?php echo e(session('error')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>

                                    <form action="<?php echo e(route('admin.login')); ?>" method="POST" class="my-4">
                                        <?php echo csrf_field(); ?> <!-- CSRF token for form security -->
                                        <div class="form-group mb-3">
                                            <label for="emailaddress" class="form-label">Email address</label>
                                            <input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="email" id="emailaddress" name="email" placeholder="Enter your email" value="<?php echo e(old('email')); ?>">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                            
                                        <div class="form-group mb-3">
                                            <label for="password" class="form-label">Password</label>
                                            <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" name="password" id="password" placeholder="Enter your password">
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
<!--                             
                                        <div class="form-group d-flex mb-3">
                                            <div class="col-sm-6">
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" id="checkbox-signin" name="remember" checked>
                                                    <label class="form-check-label" for="checkbox-signin">Remember me</label>
                                                </div>
                                            </div>
                                        </div> -->
                                        
                                        <div class="form-group mb-0 row">
                                            <div class="col-12">
                                                <div class="d-grid">
                                                    <button class="btn btn-primary" type="submit"> Log In </button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-xl-6 col-lg-6 p-0 vh-100 d-flex justify-content-center account-page-bg">
                    <!-- Optional background section -->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Vendor -->
<script src="<?php echo e(asset('assets/libs/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/node-waves/waves.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/waypoints/lib/jquery.waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/jquery.counterup/jquery.counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/feather-icons/feather.min.js')); ?>"></script>

<!-- Apexcharts JS -->
<script src="<?php echo e(asset('assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>

<!-- For basic area chart (external link remains unchanged) -->
<script src="https://apexcharts.com/samples/assets/stock-prices.js"></script>

<!-- Widgets Init Js -->
<script src="<?php echo e(asset('assets/js/pages/dashboard.init.js')); ?>"></script>

<!-- App js -->
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Development\TruckRequestOrdering\resources\views/auth/login.blade.php ENDPATH**/ ?>